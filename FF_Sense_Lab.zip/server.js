const express=require("express");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;
const API_KEY=process.env.FF_API_KEY||"";
const API_BASE=process.env.FF_API_BASE||"https://api.freefirecommunity.com";

app.use(express.static(path.join(__dirname,"public")));

app.get("/api/player",async(req,res)=>{
  const uid=String(req.query.uid||"").trim();
  const region=String(req.query.region||"br").trim().toLowerCase();
  if(!/^\d{5,15}$/.test(uid)) return res.status(400).json({error:"UID inválido."});
  if(!API_KEY) return res.status(503).json({error:"API não configurada. Defina FF_API_KEY no servidor."});
  try{
    const url=`${API_BASE.replace(/\/$/,"")}/api/v1/info?uid=${encodeURIComponent(uid)}&region=${encodeURIComponent(region)}`;
    const r=await fetch(url,{headers:{"x-api-key":API_KEY,"accept":"application/json"}});
    const text=await r.text();
    let data; try{data=JSON.parse(text)}catch{data={raw:text}}
    if(!r.ok) return res.status(r.status).json({error:data.message||data.error||"API recusou a consulta."});
    // Normaliza possíveis formatos da API
    const p=data.player||data.data||data;
    res.json({
      uid:p.uid||p.id||uid,
      nickname:p.nickname||p.player_nickname||p.name||"Jogador",
      level:p.level??p.player_level,
      region:p.region||p.player_region||region.toUpperCase()
    });
  }catch(e){res.status(502).json({error:"Não foi possível acessar a API de jogadores."})}
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`FF Sense Lab em http://localhost:${PORT}`));
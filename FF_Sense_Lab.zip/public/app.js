const $=s=>document.querySelector(s);
let player=null;

function message(t, bad=true){$("#msg").textContent=t;$("#msg").style.color=bad?"#ff8d8d":"#79e6a4";}

$("#consult").onclick=async()=>{
  const uid=$("#uid").value.trim();
  if(!/^\d{5,15}$/.test(uid)){message("Digite um UID numérico válido (5 a 15 dígitos).");return}
  message("Consultando...",false);
  try{
    const r=await fetch(`/api/player?uid=${encodeURIComponent(uid)}&region=${$("#region").value}`);
    const data=await r.json();
    if(!r.ok) throw new Error(data.error||"Não foi possível consultar o jogador.");
    player=data;
    $("#profile").classList.remove("hidden");
    $("#profile").innerHTML=`<div class="avatar">FF</div><div><strong>${escapeHtml(data.nickname||"Jogador")}</strong><small>UID: ${escapeHtml(String(data.uid||uid))} • Região: ${escapeHtml(data.region||"BR")}${data.level!=null?" • Nível: "+escapeHtml(String(data.level)):""}</small></div>`;
    message("Jogador encontrado.",false);
  }catch(e){$("#profile").classList.add("hidden");message(e.message)}
};

$("#generate").onclick=()=>{
  const dpi=Math.max(300,Math.min(1000,Number($("#dpi").value)||450));
  const style=$("#style").value;
  const device=$("#device").value;
  let base={geral:92,ponto:88,mira2:82,mira4:76,awm:48,olho:80};
  if(style==="rush") base={geral:98,ponto:95,mira2:90,mira4:82,awm:52,olho:92};
  if(style==="precision") base={geral:84,ponto:78,mira2:74,mira4:70,awm:42,olho:72};
  const factor=(dpi-450)/1000;
  const vals=Object.fromEntries(Object.entries(base).map(([k,v])=>[k,Math.max(1,Math.min(200,Math.round(v-factor*25))) ]));
  const names={geral:"Geral",ponto:"Ponto Vermelho",mira2:"Mira 2x",mira4:"Mira 4x",awm:"Mira AWM",olho:"Olhadinha"};
  $("#senses").innerHTML=Object.entries(vals).map(([k,v])=>`<div class="sense"><small>${names[k]}</small><strong>${v}</strong></div>`).join("");
  const seed=(player?.uid||"DEMO")+"-"+dpi+"-"+style+"-"+device;
  $("#access").textContent="FF-"+hash(seed).toUpperCase().slice(0,8);
  $("#result").classList.remove("hidden");
  $("#result").scrollIntoView({behavior:"smooth"});
};
$("#copy").onclick=async()=>{await navigator.clipboard.writeText($("#access").textContent);$("#copy").textContent="Copiado!";setTimeout(()=>$("#copy").textContent="Copiar",1200)};
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,"0")}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}